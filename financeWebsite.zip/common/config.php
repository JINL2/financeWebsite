<?php
/**
 * 재무관리 시스템 설정 파일
 * 환경변수 기반 설정 (보안 강화)
 */

// Load environment variables from .env file if it exists
if (file_exists(__DIR__ . '/../.env')) {
    $envFile = file(__DIR__ . '/../.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($envFile as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            list($name, $value) = explode('=', $line, 2);
            $name = trim($name);
            $value = trim($value);
            if (!getenv($name)) {
                $_ENV[$name] = $value;
                putenv("$name=$value");
            }
        }
    }
}

// Supabase 설정 - 환경변수 필수
$supabase_url = getenv('SUPABASE_URL');
$supabase_anon_key = getenv('SUPABASE_ANON_KEY');

if (!$supabase_url || !$supabase_anon_key) {
    throw new Exception('SUPABASE_URL and SUPABASE_ANON_KEY environment variables are required. Please check your .env file.');
}

define('SUPABASE_URL', $supabase_url);
define('SUPABASE_ANON_KEY', $supabase_anon_key);
define('SUPABASE_SERVICE_KEY', getenv('SUPABASE_SERVICE_KEY') ?: '');

// 페이지네이션 설정
define('DEFAULT_LIMIT', 100);
define('MAX_LIMIT', 1000);

// 시스템 설정
define('SYSTEM_NAME', '재무관리 시스템');
define('DEFAULT_TIMEZONE', 'Asia/Seoul');

// 날짜 형식
define('DATE_FORMAT', 'Y-m-d');
define('DATETIME_FORMAT', 'Y-m-d H:i:s');
define('DATE_FORMAT_KR', 'Y년 m월 d일');

// 에러 리포팅 (프로덕션 환경에서는 숨김)
if (getenv('APP_ENV') === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
}

// 타임존 설정
date_default_timezone_set(DEFAULT_TIMEZONE);

// 세션 시작
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 테스트용 사용자 정보 (환경변수로 설정 가능)
define('TEST_USER_ID', getenv('TEST_USER_ID') ?: 'your-test-user-id'); 
define('TEST_MODE', getenv('TEST_MODE') === 'true' ? true : false);
